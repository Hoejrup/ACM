
### 
# Create 1 or 2 more functions for Copula, look at summary and or print
# Create general class for "simulations" including all the sub classes
#
#

# Create summary for A-R
# Summary for Inverse sampling
# Christian can look into an "analysis" function, returning a 1page PDF with all results
#   - Consider using the methods for generating the different pages
#     - I.e. summary / plot
# 
# 
# 
# Create a vignette
#
#
#
#
#
#